-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Lug 11, 2022 alle 18:07
-- Versione del server: 10.4.24-MariaDB
-- Versione PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsc_database`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `admin`
--

CREATE TABLE `admin` (
  `idAdmin` int(6) NOT NULL,
  `NomeUtente` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Cognome` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `admin`
--

INSERT INTO `admin` (`idAdmin`, `NomeUtente`, `Password`, `Nome`, `Cognome`, `Email`) VALUES
(1, 'admin', 'password', 'Antonio', 'D Angiolella', 'antonio.da@hotmail.it');

-- --------------------------------------------------------

--
-- Struttura della tabella `clienti`
--

CREATE TABLE `clienti` (
  `id` int(5) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Cognome` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `DataDiNascita` date NOT NULL,
  `CittaNatale` varchar(50) NOT NULL,
  `Provincia` varchar(50) NOT NULL,
  `NomeUtente` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Sesso` varchar(50) NOT NULL,
  `SonoUn` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `clienti`
--

INSERT INTO `clienti` (`id`, `Nome`, `Cognome`, `Email`, `DataDiNascita`, `CittaNatale`, `Provincia`, `NomeUtente`, `Password`, `Sesso`, `SonoUn`) VALUES
(1, 'Antonio', 'D\'Angiolella', 'antonio.da@hotmail.it', '1999-10-29', 'Napoli', 'Napoli', 'user', 'password', 'Maschio', 'Privato'),
(8, 'Alfonso', 'D\'Angiolella', 'Alfonso.da@hotmail.it', '2002-02-09', 'Napoli', 'Napoli', 'alfonso020202', 'alfonso12', 'Maschio', 'Privato'),
(20, 'Nicola', 'Dongiacomo', 'snuffy@gmail.it', '2000-12-21', 'Aversa', 'Caserta', 'snuffyduck', 'nicola00', 'Maschio', 'Privato'),
(21, 'Alberto', 'Rossi', 'arossi@gmail.com', '1985-05-12', 'Porto San Giorgio', 'Fermo', 'albrossi', 'alberto85', 'Maschio', 'Titolare Azienda'),
(22, 'Giovanni', 'Storti', 'gio@gmail.com', '1957-02-20', 'Milano', 'Milano', 'giostorti57', 'giovanni57', 'Maschio', 'Titolare Azienda'),
(23, 'Carmine', 'Capone', 'carmine@gmail.com', '2001-01-08', 'Frignano', 'Caserta', 'hachrack', 'carmine01', 'Altro', 'Titolare Azienda');

-- --------------------------------------------------------

--
-- Struttura della tabella `corsi`
--

CREATE TABLE `corsi` (
  `idCorso` int(11) NOT NULL,
  `NomeCorso` varchar(50) NOT NULL,
  `DocenteCorso` varchar(50) NOT NULL,
  `DescrizioneCorso` varchar(500) NOT NULL,
  `PrezzoCorso` int(6) NOT NULL,
  `DataInizio` date NOT NULL,
  `DataFine` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `corsi`
--

INSERT INTO `corsi` (`idCorso`, `NomeCorso`, `DocenteCorso`, `DescrizioneCorso`, `PrezzoCorso`, `DataInizio`, `DataFine`) VALUES
(1, 'Corso da Pizzaiolo', 'Salvatore Esposito', 'Corso per imparare le basi della tradizione napoletana della pizza orientato ad approccio moderno', 900, '2022-07-16', '2022-07-30'),
(3, 'Corso da Analista Finanziario', 'Alberto Cavalli', 'L\'analista finanziario studia e analizza il bilancio dell\'azienda per stabilire lo stato di salute, definirne la struttura, la redditività e valutare le prospettive economiche dell\'impresa stessa.', 3500, '2022-09-01', '2022-08-20'),
(7, 'Corso da Sviluppatore Web', 'Vincenzo Salerno', 'Corso base per avere una infarinatura sullo sviluppo di sistemi web. Il corso si occuperà sia del front end che del back end.', 3600, '2022-07-25', '2022-10-27'),
(8, 'Corso da Sommelier', 'Pasquale Abbate', 'Corso pratico in cui si da una infarinatura sulla gestione dei vini nella sala di un ristorante stellato.', 1400, '2022-09-08', '2022-10-21');

-- --------------------------------------------------------

--
-- Struttura della tabella `dipendenti`
--

CREATE TABLE `dipendenti` (
  `idDipendenti` int(11) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Cognome` varchar(50) NOT NULL,
  `Stipendio` int(6) NOT NULL,
  `Dipartimento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `dipendenti`
--

INSERT INTO `dipendenti` (`idDipendenti`, `Nome`, `Cognome`, `Stipendio`, `Dipartimento`) VALUES
(1, 'Alberto', 'Cavalli', 1600, 'Insegnamento'),
(2, 'Vincenzo', 'Salerno', 3000, 'Insegnamento'),
(10, 'Pasquale', 'Abbate', 1500, 'Insegnamento'),
(14, 'Salvatore', 'Esposito', 1400, 'Insegnamento'),
(15, 'Giulio', 'Verdi', 1700, 'Vendita'),
(18, 'Bruno ', 'Bianchi', 3500, 'Dirigenza');

-- --------------------------------------------------------

--
-- Struttura della tabella `prenotazioni`
--

CREATE TABLE `prenotazioni` (
  `idPrenotazione` int(11) NOT NULL,
  `idCorsoPrenotato` int(6) NOT NULL,
  `NomePrenotazione` varchar(50) NOT NULL,
  `CognomePrenotazione` varchar(50) NOT NULL,
  `EmailPrenotazione` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `prenotazioni`
--

INSERT INTO `prenotazioni` (`idPrenotazione`, `idCorsoPrenotato`, `NomePrenotazione`, `CognomePrenotazione`, `EmailPrenotazione`) VALUES
(12, 7, 'Alfonso', 'D\'Angiolella', 'alfonso.da02@hotmail.it'),
(13, 1, 'Nicola', 'Dongiacomo', 'snuffy@gmail.it');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idAdmin`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indici per le tabelle `clienti`
--
ALTER TABLE `clienti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `Id` (`id`);

--
-- Indici per le tabelle `corsi`
--
ALTER TABLE `corsi`
  ADD PRIMARY KEY (`idCorso`);

--
-- Indici per le tabelle `dipendenti`
--
ALTER TABLE `dipendenti`
  ADD PRIMARY KEY (`idDipendenti`);

--
-- Indici per le tabelle `prenotazioni`
--
ALTER TABLE `prenotazioni`
  ADD PRIMARY KEY (`idPrenotazione`),
  ADD KEY `idCorsoPrenotato` (`idCorsoPrenotato`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `admin`
--
ALTER TABLE `admin`
  MODIFY `idAdmin` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `clienti`
--
ALTER TABLE `clienti`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT per la tabella `corsi`
--
ALTER TABLE `corsi`
  MODIFY `idCorso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `dipendenti`
--
ALTER TABLE `dipendenti`
  MODIFY `idDipendenti` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT per la tabella `prenotazioni`
--
ALTER TABLE `prenotazioni`
  MODIFY `idPrenotazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `prenotazioni`
--
ALTER TABLE `prenotazioni`
  ADD CONSTRAINT `Verifica` FOREIGN KEY (`idCorsoPrenotato`) REFERENCES `corsi` (`idCorso`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
