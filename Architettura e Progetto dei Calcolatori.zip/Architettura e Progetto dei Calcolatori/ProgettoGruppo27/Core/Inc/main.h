/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f3xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define PIN_user_button_Pin GPIO_PIN_0
#define PIN_user_button_GPIO_Port GPIOA
#define PIN_user_button_EXTI_IRQn EXTI0_IRQn
#define PIN_fotoresistore_Pin GPIO_PIN_1
#define PIN_fotoresistore_GPIO_Port GPIOA
#define PIN_sensore_temperatura_Pin GPIO_PIN_2
#define PIN_sensore_temperatura_GPIO_Port GPIOA
#define LED_mod_notte_Pin GPIO_PIN_9
#define LED_mod_notte_GPIO_Port GPIOE
#define LED_mod_giorno_2_Pin GPIO_PIN_12
#define LED_mod_giorno_2_GPIO_Port GPIOE
#define LED_mod_giorno_1_Pin GPIO_PIN_13
#define LED_mod_giorno_1_GPIO_Port GPIOE
#define LED_mod_giorno_3_Pin GPIO_PIN_14
#define LED_mod_giorno_3_GPIO_Port GPIOE
#define PIN_Servomotore_Pin GPIO_PIN_5
#define PIN_Servomotore_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
