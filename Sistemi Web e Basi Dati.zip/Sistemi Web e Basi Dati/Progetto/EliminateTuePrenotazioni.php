<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Future Systems Consulting - Eliminazione Prenotazione</title>
    <link rel="icon" type="image/x-icon" href="Favicon.jpg">
    <link rel="stylesheet" href="LoginRegistrazione.css"></head>

<body class="body2" >



    <?php

    $host = "127.0.0.1";
    $user = "root";
    $password = "";
    $database = "fsc_database";
    
    $connessione = new mysqli($host,$user,$password,$database);
      if($connessione == false){
        die("errore di connessione: " . $connessione->connect_error);
      }

    $eliminaMail = $_POST['eliminaEmail'];
    $eliminaidPrenotazione = $_POST['eliminaidPrenotazione'];

    $sql="DELETE FROM prenotazioni WHERE EmailPrenotazione = '$eliminaMail' && idPrenotazione = '$eliminaidPrenotazione' ";
    

    if($connessione->query($sql) == true){
      echo"La cancellazione è andata a buon fine! ";
      }else{
          echo"La cancellazione non è andata buon fine" . $connessione->error;
            }
    
    
    ?>



<div class="container">

    <?php

    $host = "127.0.0.1";
    $user = "root";
    $password = "";
    $database = "fsc_database";

    $connessione = new mysqli($host,$user,$password,$database);
        if($connessione == false){
            die("errore di connessione: " . $connessione->connect_error);
        }


        $sql="SELECT * FROM prenotazioni WHERE EmailPrenotazione = '$eliminaEmail' ";


    if($result = $connessione->query($sql)){
        if($result -> num_rows > 0){
        echo'
            <table style="font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            border: 2px solid #dddddd;
            text-align: left;
            padding: 8px;
            background-color: #5c5858;
            ">
            <thead>
            <tr style = "border: 2px solid #dddddd">
            <th style = "border: 2px solid #dddddd">Id Prenotazione</th> 
            <th style = "border: 2px solid #dddddd">Id Corso Prenotato</th>
            <th style = "border: 2px solid #dddddd">Nome Prenotazione </th> 
            <th style = "border: 2px solid #dddddd">Cognome Prenotazione </th> 
            <th style = "border: 2px solid #dddddd">Email Prenotazione </th> 
            
            </tr></thead><tbody>';
            while($row = $result->fetch_array()){
              echo'
              <tr>
              <td style = "border: 2px solid #dddddd">'. $row['idPrenotazione'] . '</td> 
              <td style = "border: 2px solid #dddddd">'. $row['IdCorsoPrenotato'] . '</td> 
              <td style = "border: 2px solid #dddddd">'. $row['NomePrenotazione'] . '</td> 
              <td style = "border: 2px solid #dddddd">'. $row['CognomePrenotazione'] . '</td> 
              <td style = "border: 2px solid #dddddd">'. $row['EmailPrenotazione'] . '</td> 
              </tr>
              ';
            }
            echo'</tbody></table>';
        }else{
        echo'non ci sono elementi nella tabella';
        }
    }else{
  echo'errore nell esecuzione della query' . $sql . $connessione-> error;
    }




    ?>

<form action="EliminaTuePrenotazioni.php">
            <br></br>
            <button class="btn">Elimina un altra Prenotazione</button>
            <br></br>
            
</form>

<form action="LoggatoPrivato.php">
            <br></br>
            <button class="btn">Torna Indietro</button>
            <br></br>
            
</form>
</div>
</body>
</html>
